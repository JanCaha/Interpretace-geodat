source(here::here("scripts", "_init.R"))

## zpracování dat